document.getElementById("submit").addEventListener("click", formValidation);
window.onload = function () {
    hideErrorsDiv() ;
};

function formValidation() {
    let fullname = document.getElementById("fullname").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmpassword").value;
    let phonenumber = document.getElementById("phonenumber").value;
    let organization = document.getElementById("organization").value;
    let country = document.getElementById("country").value;
    let discount = document.getElementById("discount").value;
    var discountValue;

    fullname = fullname.trim();
    email = email.trim();
    phonenumber = phonenumber.trim();
    organization = organization.trim();
    country = country.trim();
    discount = discount.trim();

    /*Full Name*/

    if (fullname.length <= 0) {
        console.log("Please enter your name");
        showErrorsDiv();
        showErrors("fullnameError");
       
    } else {
        console.log(fullname);
        hideErrors("fullnameError");
       
    }
    /*Email*/
    let emailExpression = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]/;
    if (!emailExpression.test(email)) {
        console.log("Invalid or missing email address");
        showErrorsDiv();
        showErrors("emailError");
    } else {
        console.log(email);
        hideErrors("emailError");
    }
    /*Password*/
    if (password.length < 10 || password.length > 20) {
        console.log("Password must be between 10 and 20 characters");
        showErrorsDiv();
        showErrors("passwordError");
      
    } else {
        hideErrors("passwordError");
       
    }

    if (!password.match(/[a-z]/g)) {
        console.log("Password must contain at least one lowercase character");
        showErrorsDiv();
        showErrors("passwordError1");
       
    } else {
        hideErrors("passwordError1");
        
    }

    if (!password.match(/[A-Z]/g)) {
        console.log("Password must contain at least one uppercase character");
        showErrorsDiv();
        showErrors("passwordError2");
        
    } else {
        hideErrors("passwordError2");
        
    }

    if (!password.match(/[0-9]/g)) {
        console.log("Password must contain at least one digit");
        showErrorsDiv();
        showErrors("passwordError3");
        
    } else {
        hideErrors("passwordError3");
        
    }

    if (password != confirmPassword) {
        console.log("Password and confirmation password don’t match");
        showErrorsDiv();
        showErrors("passwordError4");
        
    } else {
        hideErrors("passwordError4");
      
    }

    console.log(password);
    console.log(confirmPassword);

    /*Phone*/
    let phoneExpression = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (!phoneExpression.test(phonenumber)) {
        console.log("Wrong phone number provided");
        showErrorsDiv();
        showErrors("phonenumberError");
       
    } else {
        console.log(phonenumber);
        hideErrors("phonenumberError");
        
    }
    /*Organization*/
    if (organization.length <= 0) {
        console.log("Missing attendee organization");
        showErrorsDiv();
        showErrors("organizationError");
        
    } else {
        console.log(organization);
        hideErrors("organizationError");
        
    }

    /*Country*/
    if (country.length <= 0) {
        console.log("Missing attendee country");
        showErrorsDiv();
        showErrors("countryError");
       
    } else {
        console.log(country);
        hideErrors("countryError");
        
    }
    /*Regtype*/
    const rbs = document.querySelectorAll('input[name="regtype"]');
    var amount;
    for (const rb of rbs) {
        if (rb.checked) {
            amount = rb.value;
            break;
        }
    }
    console.log("Amount before:");
    console.log(amount);

    /*Discount*/
    if (discount.toLowerCase() === "Lehman".toLowerCase()) {
        discountValue = amount * 0.5;
        console.log(discountValue);
        amount = amount - discountValue;
    } else {
        discountValue = 0;
        console.log(discountValue);
        amount = amount - discountValue;
    }

    console.log("Amount after:");
    console.log(amount);
    console.log("Total with discount: $" + amount)
    
    
}



function showErrors(divName) {
    let errorsDiv = document.getElementById(divName);
    errorsDiv.style.display = "list-item";
}

function hideErrors(divName) {
    let errorsDiv = document.getElementById(divName);
    errorsDiv.style.display = "none";
}

function showErrorsDiv() {
    document.getElementById("formErrors").style.display = "block";
}

function hideErrorsDiv() {
    document.getElementById("formErrors").style.display = "none";
}
