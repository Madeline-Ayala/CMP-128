/* External JavaScript*/


function clearOutput(){
	 document.getElementById("output-value").innerHTML = " ";
	}

function output(value){
	document.getElementById("output-value").innerHTML += value;  
}
function solve(){

	var equation = document.getElementById("output-value").innerHTML;
	var solved = eval(equation);
	document.getElementById("output-value").innerHTML = solved;
}